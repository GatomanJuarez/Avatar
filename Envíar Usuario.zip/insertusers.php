<?php
    
    include("Conexion4B.php");  
    
    $nombre = $_POST["usuario"]; //Usuario proviene de: <input name="nombre">
    $pass = $_POST["password"]; //Contraseña proviene de: <input name="password">
    $rol = $_POST["rol"]; //Rol de Usuario proviene de: <select name="rol">    

    //$mysqli->query("INSERT INTO usuarios (nombre) VALUES ('$nombre')"); //Insercion de la Base de datos

    if($nombre == "" || $pass == "" || $rol == "none"){ //Datos incompletos
        echo("Los Datos están incompletos.<br>Regresa y llena todos los campos.");
    }
    else{ //Datos completos
        $mysqli->query("INSERT INTO usuarios (nombre, password, rol)
                                VALUES ('$nombre','$pass','$rol')"); //Inserción en MySQL
        
        if($mysqli->errno == 0){ //Revisando Errores de x tipo
            //Libre de errores
            echo("El registro de usuario se realizó exitosamente");
        }
        else{ //Ha ocurrido un error            
            echo("Ha ocurrido un problema con el registro.
            <br>Por favor vuelva a intentarlo");
        }
    }
    
    

    //Depurar: URL + XDEBUG_SESSION_START=xdebug
    
?>